#include <stdio.h>
void main()
{float sp,bp,profit;
scanf("%f%f",&sp,&profit);
bp=(profit-sp)/15;
printf("%f",bp);
}



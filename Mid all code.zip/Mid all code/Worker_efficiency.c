#include<stdio.h>
void main()
{
    int wh;
    scanf("%d",&wh);
    if (wh>=2&&wh<=3)
        printf("highly efficient");
    else if
        (wh>=3&&wh<=4)
        printf("ordered to improve speed");
    else if
        (wh>=4&&wh<=5)
        printf("needed training for improving speed");
    else if
        (wh>5)
        printf("terminated");
}

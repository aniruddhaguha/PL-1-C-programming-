#include<stdio.h>

int main ()
{
float f,c;
printf ("City Temperature in Celsius: ");
scanf ("%f",& c);
f=(c*1.8)+32;
printf ("City Temperature in Fahrenheit: %f",f);

}

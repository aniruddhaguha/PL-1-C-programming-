#include<stdio.h>
void main ()
{
    int cr,jy,sy;
    scanf("%d%d",&cr,&jy);

    if
   (sy>3)
    {printf ("Will get bonus 2500")};
    else
    {printf("none");

    }

}

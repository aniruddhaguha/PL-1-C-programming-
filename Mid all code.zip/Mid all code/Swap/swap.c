#include <stdio.h>
void main()
{int a,b,c=0;
scanf("%d%d",&a,&b);
a=b;
b=c;
c=a;
printf("%d",c);
}

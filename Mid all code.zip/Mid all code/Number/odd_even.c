#include<stdio.h>
void main()
{
    int n,i;
    for(i=1;i<=10;i++)
        {scanf("%d",&n);
    if
        (n%2==0)
        printf("even");
    else
        printf("odd");
        }
}

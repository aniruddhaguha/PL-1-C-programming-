#include <stdio.h>
void main()
{
    int i,s;
    for(i=1;i<=10;i++)
{   s=i*i;
    printf("%d\n",s);
}
}

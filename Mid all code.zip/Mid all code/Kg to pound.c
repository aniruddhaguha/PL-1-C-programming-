#include <stdio.h>
void main()
{float kg,pound=0;
scanf("%f",&kg);
pound=kg*2.2;
printf("%f",pound);
}

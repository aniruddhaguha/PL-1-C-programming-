#include<stdio.h>
void main()
{
    int cy,jy,sy,i;
    for (i=1;i<=50;i++)
    {scanf("%d%d",&cy,&jy);
    sy=cy-jy;
    if (sy>3)
    printf("bonus 16500 taka");
    else
    printf("no bonus");}

}

#include<stdio.h>
int main ()
{
    int i, j;
        for (i=0;i<5;i++)
        {
            for (j=i;j<5;j++)
            {
                printf ("I: %d \t J: %d \n",i,j);
            }
        }
}

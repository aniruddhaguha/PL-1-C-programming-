#include<stdio.h>

int main ()
{
float f,c;
printf ("City Temperature in Fahrenheit:");
scanf ("%f",& f);
c=(f-32)/1.8;
printf ("City Temperature in Celsius: %f",c);

}

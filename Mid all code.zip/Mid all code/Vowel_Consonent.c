#include<stdio.h>
void main()
{
    char x;
    scanf("%c",&x);
    if
        (x=='A'||x=='a')
        printf("Vowel");
   else if
        (x=='E'||x=='e')
        printf("Vowel");
    else if
        (x=='I'||x=='i')
        printf("Vowel");
    else if
        (x=='O'||x=='o')
        printf("Vowel");
    else if
        (x=='U'||x=='u')
        printf("Vowel");
    else
        printf("Consonant");

}

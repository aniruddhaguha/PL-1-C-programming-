#include <stdio.h>
void main()
{
    int i,fact=1;
    for(i=1;i<=15;i++)
    {
        fact=fact*i;
        printf("%d\n",fact);
    }

}

#include<stdio.h>

int main()
{
int x;
x = sizeof (char);
printf ("The size is: %d",x);
}
